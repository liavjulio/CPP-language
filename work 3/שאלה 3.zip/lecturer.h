#pragma once
#include "resercher.h"
#include "teacher.h"
class lecturer :public resercher,public teacher
{
private:
public:
	lecturer();
	lecturer(char* name, int sen, course* a, article* b, int Asize, int Bsize);
	~lecturer();
	void print_article();
	virtual const char* get_type();
	virtual const char* get_name();
	void add_article(char* n);
	void print();
};

