#define _CRT_SECURE_NO_WARNINGS
#include "resercher.h"
#include <iostream>
using namespace std;
resercher::resercher()
{
	arrsize2 = 0;
	arr2 = NULL;
}

resercher::resercher(char* name, int sen, article* a, int size):worker(name,seniority)
{
	worker::seniority = sen;
	arrsize2 = size;
	worker::salary = (size * 3000) + 5000 + (1000 * this->seniority);
	arr2 = new article[arrsize2];
	if (!arr2)
	{
		cout << "error" << endl;
		arr2 = NULL;
	}
	for (int i = 0; i < size; i++)
	{
		arr2[i].art_name = new char[strlen(a[i].art_name) + 1];
		strcpy(arr2[i].art_name, a[i].art_name);
	}
}
void resercher::print_article()
{
	for (int i = 0; i < arrsize2; i++)
	{
		cout << "article name : " << arr2[i].art_name << endl;
	}
}
resercher::~resercher()
{
	for (int i = 0; i < arrsize2; i++)
	{
		arr2[i].~article();
	}
}
const char* resercher::get_type()
{
	return "resercher";
}
void resercher::add_article(char* n)
{
	int temparrsize = arrsize2 + 1;
	article* temp = new article[temparrsize];
	if (!temp)
	{
		cout << "error" << endl;
		temp = NULL;
	}
	for (int i = 0; i < temparrsize-1; i++)
	{
		temp[i].art_name = new char[strlen(arr2[i].art_name) + 1];
		strcpy(temp[i].art_name, arr2[i].art_name);
	}
	temp[temparrsize - 1] = new char[strlen(n) + 1];
	strcpy(temp[temparrsize-1].art_name,n);
	arr2->~article();
	arr2 = new article[temparrsize];
	if (!arr2)
	{
		cout << "error" << endl;
		arr2 = NULL;
	}
	for (int i = 0; i < temparrsize; i++)
	{
		arr2[i].art_name = new char[strlen(temp[i].art_name) + 1];
		strcpy(arr2[i].art_name, temp[i].art_name);
	}
	salary += 3000;
	arrsize2 = temparrsize;
	temp->~article();
}
const char* resercher::get_name()
{
	return name;
}
void resercher::print()
{
	worker::print();
}