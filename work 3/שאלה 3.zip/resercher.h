#pragma once
#include "worker.h"
#include "article.h"
class resercher :virtual public worker
{
protected :
	int arrsize2;
	article* arr2;
public:
	resercher();
	resercher(char* name, int sen, article* a, int size);
	~resercher();
	void print_article();
	virtual const char* get_type();
	virtual const char* get_name();
	virtual void add_article(char* n);
	virtual void print();
};

