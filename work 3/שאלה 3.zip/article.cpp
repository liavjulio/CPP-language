﻿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "article.h"
using namespace std;
article::article()
{
	art_name = NULL;
}
article::article(char* temp)
{
	art_name = new char[strlen(temp) + 1];
	if (!art_name)
	{
		cout << "error" << endl;
		art_name = NULL;
	}
	strcpy(art_name, temp);
}
void article::set(char* n)
{
	art_name = new char[strlen(n) + 1];
	if (!art_name)
	{
		cout << "error" << endl;
		art_name = NULL;
	}
	strcpy(art_name, n);
}

article::~article()
{
	delete art_name;
}