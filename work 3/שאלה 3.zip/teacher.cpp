#define _CRT_SECURE_NO_WARNINGS
#include "teacher.h"
#include <iostream>
using namespace std;
teacher::teacher()
{
	arrsize1 = 0;
	arr1 = NULL;
}
teacher::teacher(char* name, int sen, course* a,int size) :worker(name, seniority)
{
	worker::seniority = sen;
	int total_hours = 0,over_100 = 0;
	for (int i = 0; i < size; i++)
	{
		total_hours += a[i].weekly_hours;
		if (a[i].students_num >= 100)
		{
			over_100++;
		}
	}
	worker::salary = (total_hours * 800) + (300 * over_100) + (400 * seniority);
	arrsize1 = size;
	arr1 = new course[arrsize1];
	if (!arr1)
	{
		cout << "error" << endl;
		arr1 = NULL;
	}
	for (int i = 0; i < size; i++)
	{
		arr1[i].course_name = new char[strlen(a[i].course_name) + 1];
		strcpy(arr1[i].course_name,a[i].course_name);
		arr1[i].students_num = a[i].students_num;
		arr1[i].weekly_hours = a[i].weekly_hours;
	}
}
const char* teacher::get_name()
{
	return name;
}
teacher::~teacher()
{
	for (int i = 0; i < arrsize1; i++)
	{
		arr1[i].~course();
	}
}
const char* teacher::get_type()
{
	return "teacher";
}
void teacher::print_course()
{
	for (int i = 0; i < arrsize1; i++)
	{
		if (arr1[i].students_num>=100)
		{
			cout << arr1[i].course_name << endl;
		}
	}
}
void teacher::print()
{
	worker::print();
}