#pragma once
#include "worker.h"
#include "course.h"
class teacher :virtual public worker
{
protected:
	int arrsize1;
	course* arr1;
public:
	teacher();
	teacher(char *name,int sen,course*a,int size);
	~teacher();
	const char* get_type();
	void print_course();
	virtual const char* get_name();
	virtual void print();
};

