#pragma once
class worker
{
protected:
	char* name;
	int seniority;
	int salary=0;
public:
	worker();
	worker(char* n, int s);
	~worker();
	virtual const char* get_type();
	virtual const char* get_name();
	virtual void print();

};
