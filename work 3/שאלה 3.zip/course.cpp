#define _CRT_SECURE_NO_WARNINGS
#include "course.h"
#include <iostream>
using namespace std;

course::course()
{
	students_num = 0;
	weekly_hours = 0;
	course_name = NULL;
}
course::~course()
{
	delete[] course_name;
}

void course::set(char* n, int h, int s)
{
	students_num = s;
	weekly_hours = h;
	course_name = new char[strlen(n) + 1];
	if (!course_name)
	{
		cout << "error" << endl;
		course_name = NULL;
	}
	strcpy(course_name, n);
}
