#define _CRT_SECURE_NO_WARNINGS
#include "lecturer.h"
#include <iostream>
using namespace std;
lecturer::lecturer()
{
}

lecturer::lecturer(char* name, int sen, course* a, article* b, int Asize, int Bsize) :resercher(name, sen, b, Bsize), teacher(name, sen, a, Asize), worker(name, seniority)
{
	worker::seniority = sen;
	worker::salary = 0;
	int total_hours = 0;
	for (int i = 0; i < Asize; i++)
	{
		total_hours += a[i].weekly_hours;
	}
	worker::salary = (total_hours * 1000) + (2000 * Bsize) + (700 * sen);
	arrsize1 = Asize;
	arrsize2 = Bsize;
	worker::seniority = sen;
	arr1 = new course[Asize];
	if (!arr1)
	{
		cout << "error" << endl;
		arr1 = NULL;
	}
	arr2 = new article[Bsize];
	if (!arr2)
	{
		cout << "error" << endl;
		arr2 = NULL;
	}
	for (int i = 0; i < Asize; i++)
	{
		arr1[i].course_name = new char[strlen(a[i].course_name) + 1];
		strcpy(arr1[i].course_name,a[i].course_name);
		arr1[i].weekly_hours = a[i].weekly_hours;
		arr1[i].students_num = a[i].students_num;
	}
	for (int i = 0; i < Bsize; i++)
	{
		arr2[i].art_name = new char[strlen(b[i].art_name) + 1];
		strcpy(arr2[i].art_name,b[i].art_name);
	}
}
void lecturer::add_article(char* n)
{
	resercher::add_article(n);
	worker::salary -= 1000;
}
void lecturer::print_article()
{
	for (int i = 0; i < arrsize2; i++)
	{
		cout << "article name : " << arr2[i].art_name << endl;
	}
}
const char* lecturer::get_name()
{
	return name;
}
lecturer::~lecturer()
{
}

const char* lecturer::get_type()
{
	return "lecturer";
}
void lecturer::print()
{
	worker::print();
}
