#define _CRT_SECURE_NO_WARNINGS
#include "worker.h"
#include <iostream>
using namespace std;

worker::worker()
{
	name = NULL;
	seniority = 0;
	salary = 0;
}
worker::worker(char* n, int s)
{
	seniority = s;
	name = new char[strlen(n) + 1];
	if (!name)
	{
		cout << "error" << endl;
		name = NULL;
	}
	strcpy(name, n);
	salary = 6000 + (400 * seniority);
}
const char* worker::get_name()
{
	return name;
}
worker::~worker()
{
	delete []name;
}
const char* worker::get_type()
{
	return "worker";
}
void worker::print() 
{
	cout << "worker name :" << name << "\this salary: " << salary << endl;
}