#pragma once
class course
{
private:
	char* course_name;
	int weekly_hours;
	int students_num;
public:
	course();
	~course();
	void set(char* n, int h, int s);
	friend class teacher;
	friend class lecturer;
};