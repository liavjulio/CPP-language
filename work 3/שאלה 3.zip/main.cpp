#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "article.h"
#include"course.h"
#include "lecturer.h"
#include "resercher.h"
#include "teacher.h"
#include "worker.h"
using namespace std;

int main()
{
	int size;
	int num,num1;
	int seniority = 0;
	char name[20];
	char tempname[20];
	char temp[50];
	char* course_name;
	char* article_name;
	int weekly_hours;
	int students_num;
	course* arr1;
	article* arr2;
	worker** arr;
	cout << "enter size" << endl;
	cin >> size;
	arr = new worker * [size];
	if (!arr)
	{
		cout << "error" << endl;
		return 0;
	}
	int choise;
	for (int i = 0; i < size; i++)
	{
		cout << "1-general worker , 2-teacher,3-resercher,4-lecturer" << endl;
		cin >> choise;
		cout << "enter name" << endl;
		cin >> name;
		switch (choise)
		{
		case 1:
			cout << "enter seniority:" << endl;
			cin >> seniority;
			arr[i] = new worker(name, seniority);
			arr[i]->print();
			break;
		case 2:
			cout << "enter num of courses" << endl;
			cin >> num;
			arr1 = new course[num];
			for (int j = 0; j < num; j++)
			{
				cout << "enter course"<< (j+1) <<"name:" << endl;
				cin >> temp;
				course_name = new char[strlen(temp) + 1];
				if (!course_name)
				{
					cout << "error"<<endl;
					course_name = NULL;
					return 0;
				}
				strcpy(course_name, temp);
				cout << "enter weekly hours" << endl;
				cin >> weekly_hours;
				cout << "enter students numbers" << endl;
				cin >> students_num;
				arr1[j].set(course_name, weekly_hours, students_num);
				delete[]course_name;
			}
			cout << "enter seniority:" << endl;
			cin >> seniority;
			arr[i] = new teacher(name,seniority,arr1,num);
			arr[i]->print();
			break;
		case 3:
			cout << "enter num of articles" << endl;
			cin >> num1;
			arr2 = new article[num1];
			for (int j = 0; j < num1; j++)
			{
				cout << "enter article " << (j + 1) << " name:" << endl;
				cin >> temp;
				article_name = new char[strlen(temp) + 1];
				if (!article_name)
				{
					cout << "error" << endl;
					article_name = NULL;
					return 0;
				}
				strcpy(article_name, temp);
				arr2[j].set(article_name);
				delete[]article_name;
			}
			cout << "enter seniority:" << endl;
			cin >> seniority;
			arr[i] = new resercher(name, seniority,arr2,num1);
			arr[i]->print();
			break;
		case 4:
			cout << "enter num of articles" << endl;
			cin >> num1;
			arr2 = new article[num1];
			if (!arr2)
			{
				cout << "error" << endl;
				arr2 = NULL;
				return 0;
			}
			for (int j = 0; j < num1; j++)
			{
				cout << "enter article " << (j + 1) << " name:" << endl;
				cin >> temp;
				article_name = new char[strlen(temp) + 1];
				if (!article_name)
				{
					cout << "error" << endl;
					article_name = NULL;
					return 0;
				}
				strcpy(article_name, temp);
				arr2[j].set(article_name);
				delete []article_name;
			}
			cout << "enter num of courses" << endl;
			cin >> num;
			arr1 = new course[num];
			if (!arr1)
			{
				cout << "error" << endl;
				arr1 = NULL;
				return 0;
			}
			for (int j = 0; j < num; j++)
			{
				cout << "enter course" << (j + 1) << "name:" << endl;
				cin >> temp;
				course_name = new char[strlen(temp) + 1];
				if (!course_name)
				{
					cout << "error" << endl;
					course_name = NULL;
					return 0;
				}
				strcpy(course_name, temp);
				cout << "enter weekly hours" << endl;
				cin >> weekly_hours;
				cout << "enter students numbers" << endl;
				cin >> students_num;
				arr1[j].set(course_name, weekly_hours, students_num);
				delete []course_name;
			}
			cout << "enter seniority:" << endl;
			cin >> seniority;
			arr[i] = new lecturer(name, seniority, arr1,arr2,num,num1);
			arr[i]->print();
			break;
		default:
			break;
		}
	}
	cout << "1-add article,2-print all,3-print courses with at least 100 students,4-print all articles,5-exit" << endl;
	cin >> choise;
	while (choise)
	{
		switch (choise)
		{
		case 1:
			cout << "enter worker name:" << endl;
			cin >> tempname;
			for (int i = 0; i < size; i++)
			{
				if (!strcmp(tempname, arr[i]->get_name()))
				{
					if ((arr[i]->get_type() == "resercher") || (arr[i]->get_type() == "lecturer"))
					{
						if ((arr[i]->get_type() == "lecturer"))
						{
							cout << "enter article name" << endl;
							cin >> temp;
							article_name = new char[strlen(temp) + 1];
							strcpy(article_name, temp);
							dynamic_cast <lecturer*> (arr[i])->add_article(article_name);
							delete []article_name;
							break;
						}
						else
						{
							cout << "enter article name" << endl;
							cin >> temp;
							article_name = new char[strlen(temp) + 1];
							strcpy(article_name, temp);
							dynamic_cast <resercher*> (arr[i])->add_article(article_name);
							delete []article_name;
							break;
						}
					}
				}
			}
			break;
		case 2:
			for (int i = 0; i < size; i++)
			{
				arr[i]->print();
			}
			break;
		case 3:
			for (int i = 0; i < size; i++)
			{
				if ((arr[i]->get_type() == "lecturer") || (arr[i]->get_type() == "teacher"))
				{
					if ((arr[i]->get_type() == "lecturer"))
					{
						dynamic_cast <lecturer*> (arr[i])->print_course();
					}
					else
					{
						dynamic_cast <teacher*> (arr[i])->print_course();
					}
				}
			}
			break;
		case 4:
			for (int i = 0; i < size; i++)
			{
				if ((arr[i]->get_type() == "resercher") || (arr[i]->get_type() == "lecturer"))
				{
					if ((arr[i]->get_type() == "lecturer"))
					{
						dynamic_cast <lecturer*> (arr[i])->print_article();
					}
					else
					{
						dynamic_cast <resercher*> (arr[i])->print_article();
					}
				}
			}
			break;
		case 5:
			for (int i = 0; i < size; i++)
			{
				arr[i]->~worker();
			}
			delete []arr;
			return 0;
		default:
			break;
		}
	cout << "1-add article,2-print all,3-print courses with at least 100 students,4-print all articles,5-exit" << endl;
	cin >> choise;
	}
}
