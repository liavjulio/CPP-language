#pragma once
class article
{
private:
	char* art_name;
public:
	article();
	article(char* temp);
	virtual ~article();
	void set(char* n);
	friend class resercher;
	friend class lecturer;
};