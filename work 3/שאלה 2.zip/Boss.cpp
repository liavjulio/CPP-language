#include <iostream>
#include "worker.h"
#include "Boss.h"
using namespace std;
Boss::Boss()
{
	salary = 0;
}
Boss::Boss(char *name,long id,int seniority):worker(name,id,seniority)
{
	salary = ((1000 * seniority) + 14000);
}
Boss::~Boss()
{

}
long Boss::get_id()
{
	return id;
}
const char* Boss::type()
{
	return "boss";
}
void Boss::print() const
{
	worker::print();
	cout << "his salary :" << salary << endl;
}
