#pragma once
#include <iostream>
#include "worker.h"
#include "deliveries.h"
class driver :public worker, public deliveries
{
private:
	int salary;
	int arrsize;
	deliveries* arr;
	/*char type[2] = "d";*/
public:
	driver();
	driver(char* name, long id, int seniority, deliveries* a, int size);
	void add(int distance, int cargo_weight);
	~driver();
	const char* type();
	int get_arr();
	long get_id();
	int over_weigth();
	void print()const;
};
