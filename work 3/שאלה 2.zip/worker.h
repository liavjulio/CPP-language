#pragma once
#include <iostream>
class worker
{
protected:
	char* name;
	long id;
	int seniority;
public:
	worker();
	worker(char* n, long i, int sen);
	~worker();
	virtual const char* type();
	virtual void print() const;
	virtual long get_id();
	virtual int get_arr();
};