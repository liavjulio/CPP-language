#pragma once
#include <iostream>
#include "worker.h"
class Boss:public worker
{
private:
	int salary;
public:
	Boss();
	Boss(char* name,long id, int seniority);
	~Boss();
	void print() const;
	const char* type();
	long get_id();
};