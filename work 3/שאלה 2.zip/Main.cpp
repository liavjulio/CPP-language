#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
using namespace std;
#include "worker.h"
#include "Boss.h"
#include "deliveries.h"
#include "mechenic.h"
#include "driver.h"

int main()
{
	int t=0,z=0;
	worker** arr = NULL;
	deliveries* arr1 = NULL;
	int size;
	cout << "enter size of workers:" << endl;
	cin >> size;
	arr = new worker* [size];
	if (!arr)
	{
		cout << "error"<<endl;
		return 0;
	}
	for (int i = 0; i < size; i++)
	{
		char str[30];
		cout << "enter name" << endl;
		cin >> str;
		char* name;
		name = new char[strlen(str) + 1];
		strcpy(name, str);
		long id;
		int seniority;
		int type;
		cout << "enter type : 1-driver,2-mechenic,3-boss" << endl;
		cin >> type;
		switch (type)
		{
		case 1:
			int delivery;
			int cargo, km;
			arr1 = new deliveries[size];
			if (!arr1)
			{
				cout << "error" << endl;
				return 0;
			}
			cout << "enter id:" << endl;
			cin >> id;
			cout << "enter seniority:" << endl;
			cin >> seniority;
			cout << "enter number of deliveries:" << endl;
			cin >> delivery;
			for (int x = 0; x < delivery; x++)
			{
				cout << "enter cargo weight" << endl;
				cin >> cargo;
				cout << "enter distance" << endl;
				cin >> km;
				arr1[x].set(km, cargo);
			}
			arr[i] = new driver(name, id, seniority,arr1,delivery);
			arr[i]->print();
			break;
		case 2:
			int extra_hours;
			cout << "enter id:" << endl;
			cin >> id;
			cout << "enter seniority:" << endl;
			cin >> seniority;
			cout << "enter extra hours:" << endl;
			cin >> extra_hours;
			arr[i] = new mechenic(name, id, seniority,extra_hours);
			arr[i]->print();
			break;
		case 3:
			cout << "enter id:" << endl;
			cin >> id;
			cout << "enter seniority:" << endl;
			cin >> seniority;
			arr[i] = new Boss(name, id, seniority);
			arr[i]->print();
			break;
		default:
			break;
		}
	

	}
	int choise;
	int check = 0;
	int extratimemech = 0;
	cout << "enter your choise,1-add,2-print all,3-print over 8000 kg deliveries,4-print all mechenics with extra hours,5-exit" << endl;
	cin >> choise;
	while (choise)
	{
		switch (choise)
		{
		case 1:
			long tempID;
			int num;
			int tempCARGO, tempKM;
			cout << "enter worker id" << endl;
			cin >> tempID;
			for (int i = 0; i < size; i++)
			{
				if (arr[i]->type() == "driver")
				{
					if (tempID == arr[i]->get_id())
					{
						cout << "enter number of deliveries" << endl;
						cin >> num;
						for (int x = 0; x < num; x++)
						{
							cout << "enter cargo" << endl;
							cin >> tempCARGO;
							cout << "enter km" << endl;
							cin >> tempKM;
							dynamic_cast <driver*>(arr[i])->add(tempKM, tempCARGO);
							check++;
						}
						break;
					}
				}
			}
			if (check == 0)
			{
				cout << "error id" << endl;
			}
			check = 0;
			break;
		case 2:
			for (int i = 0; i < size; i++)
			{
				arr[i]->print();
			}
			break;
		case 3:
			if ((arr[0]->type() == "driver")&&(size == 1))
			{
				check = dynamic_cast <driver*>(arr[0])->over_weigth();
				cout << check << endl;
			}
			else
			{
				int flag = 0;
				for (int i = 0; i < size; i++)
				{
					if (arr[i]->type() == "driver")
					{
						flag = 1;
					}
				}
				if (flag == 0)
				{
					cout << "error" << endl;
					break;
				}
				else
				{
					for (int i = 0; i < size; i++)
					{
						if (arr[i]->type() == "driver")
						{
							check += dynamic_cast <driver*>(arr[i])->over_weigth();
						}
					}
					cout << check << endl;
				}
			}
		
			break;
		case 4:
			for (int i = 0; i < size; i++)
			{
				if (arr[i]->type() == "mechenic")
				{
					if (dynamic_cast <mechenic*>(arr[i])->get_extratimemech()>0)
					{
						cout << dynamic_cast <mechenic*>(arr[i])->get_name() << endl;
					}
				}
			}
			break;
		case 5:
			for (int i = 0; i < size; i++)
			{
				delete arr[i];
			}
			delete[]arr;
			delete[]arr1;
			cout << "goodbye" << endl;
			return 0;
		}
		cout << "enter your choise,1-add,2-print all,3-print over 8000 kg deliveries,4-print all mechenics with extra hours,5-exit" << endl;
		cin >> choise;
	}

}