#include <iostream>
using namespace std;
#include "mechenic.h"
#include "worker.h"
mechenic::mechenic()
{
	salary = 0;
	extra = 0;
}
mechenic::mechenic(char* name, long id, int seniority,int e):worker(name,id,seniority)
{
	extra = e;
	salary = 6000;
	salary += (seniority * 500)+(extra * 100);
}
mechenic::~mechenic() 
{

}
void mechenic::print() const
{
	worker::print();
	cout << "his salary :" << salary << endl;
}
const char* mechenic::type()
{
	return "mechenic";
}
long mechenic::get_id()
{
	return id;
}
int mechenic::get_extratimemech()
{
	int ex = 0;
	if (extra>0)
	{
		ex++;
	}
	else
	{
		return ex;
	}
	return ex;
}
const char* mechenic::get_name()
{
	return name;
}
