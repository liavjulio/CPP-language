#pragma once
#include <iostream>
class deliveries
{
protected:
	int distance;
	int cargo_weigth;
public:
	deliveries();
	~deliveries();
	void set(int d, int c);
	friend class driver;
};