#pragma once
#include "deliveries.h"
deliveries::deliveries()
{
	cargo_weigth = 0;
	distance = 0;
}
deliveries::~deliveries()
{
}
void deliveries::set(int d, int c)
{
	cargo_weigth = c;
	distance = d;
}