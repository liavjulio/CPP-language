#pragma once
#include <iostream>
#include "worker.h"
class mechenic :public worker
{
private:
	int extra;
	int salary;
public:
	mechenic();
	mechenic(char*name,long id,int seniority,int e);
	~mechenic();
	int get_extratimemech();
	const char* type();
	void print() const;
	const char* get_name();
	long get_id();
};