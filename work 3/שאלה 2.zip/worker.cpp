#define _CRT_SECURE_NO_WARNINGS
using namespace std;
#include <iostream>
#include "worker.h"

worker::worker()
{
	name = NULL;
	id = 0;
	seniority = 0;
}
worker::worker(char* n, long i, int sen)
{
	name = new char[strlen(n) + 1];
	strcpy(name,n);
	id = i;	
	seniority = sen;
}
worker::~worker()
{
	delete name;
}
void worker::print() const
{
	cout << "name: " << name << endl;
}
long worker::get_id()
{
	return id;
}

const char* worker::type()
{
	return "worker";
}
int worker::get_arr()
{
	return 0;
}