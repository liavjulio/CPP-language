using namespace std;
#include <iostream>
#include "driver.h"
#include "deliveries.h"
driver::driver():worker()
{
	salary = 0;
	arrsize = 0;
	arr = NULL;
}
driver::driver(char* name,long id,int seniority,deliveries* a,int size):worker(name, id, seniority)
{ 
	arrsize = size;
	arr = new deliveries[size];
	if (!arr)
	{
		cout << "error" << endl;
		arr = NULL;
	}
	for (int i = 0; i < size; i++)
	{
		arr[i].cargo_weigth = a[i].cargo_weigth;
		arr[i].distance = a[i].distance;
	}
	salary = 0;
	salary += (seniority * 300);
	for (int i = 0; i < size; i++)
	{
		salary += 100+(a[i].distance * 2);
		if ((a[i].cargo_weigth > 8000) && (seniority >= 3))
			{
				salary += 200;
			}
	}
}
driver::~driver()
{
	delete[]arr;
}
void driver::print() const
{
	worker::print();
	cout << "his salary :" << salary << endl;
}
const char* driver::type()
{
	return "driver";
}
long driver::get_id()
{
	return id;
}
int driver::get_arr()
{
	return arrsize;
}
void driver::add(int dis, int cargo)
{
	arrsize += 1;
	deliveries* temparr = new deliveries[arrsize];
	if (!temparr)
	{
		cout << "error" << endl;
		temparr = NULL;
	}
	for (int i = 0; i < arrsize-1; i++)
	{
		temparr[i].cargo_weigth = arr[i].cargo_weigth;
		temparr[i].distance = arr[i].distance;
	}
	temparr[arrsize-1].cargo_weigth = cargo;
	temparr[arrsize-1].distance = dis;
	arr = new deliveries[arrsize];
	if (!arr)
	{
		cout << "error" << endl;
		arr = NULL;
	}
	for (int i = 0; i < arrsize; i++)
	{
		arr[i].cargo_weigth = temparr[i].cargo_weigth;
		arr[i].distance = temparr[i].distance;
	}
	salary += 100;
	salary += (2 * dis);
	if ((seniority>=3)&&(cargo>= 8000))
	{
		salary += 200;
	}
	delete[]temparr;
}
int driver::over_weigth()
{
	int check=0;
	for (int i = 0; i < arrsize; i++)
	{
		if (arr[i].cargo_weigth>8000)
			check++;
	}
	return check;
}